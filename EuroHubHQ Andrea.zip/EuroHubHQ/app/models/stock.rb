class Stock < ApplicationRecord
  belongs_to :product
end
