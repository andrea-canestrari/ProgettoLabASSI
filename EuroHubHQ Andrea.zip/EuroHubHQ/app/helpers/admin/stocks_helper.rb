module Admin::StocksHelper
end
