require "test_helper"

class Admin::OrderTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
