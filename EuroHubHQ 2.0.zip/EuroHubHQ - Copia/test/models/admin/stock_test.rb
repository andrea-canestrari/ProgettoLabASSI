require "test_helper"

class Admin::StockTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
