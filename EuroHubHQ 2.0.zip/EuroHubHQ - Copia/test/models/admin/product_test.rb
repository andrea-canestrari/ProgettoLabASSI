require "test_helper"

class Admin::ProductTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
